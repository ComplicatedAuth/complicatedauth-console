# `@dokosoko/widget`

```ts
import { mountWidget } from "@dokosoko/widget";

mountWidget({
  widgetId: "your-public-widget-id",
  getToken: () => fetch("/api/dokosoko/widget-token", {
    method: "POST",
    credentials: "same-origin",
  }).then((response) => response.json()),
});
```

`getToken` must call your authenticated backend. Never place a DokoSoko widget secret in browser code.

## Options

| Option | Required | Description |
| --- | --- | --- |
| `widgetId` | Yes | Public UUID from the widget workspace. |
| `getToken` | Yes | Calls your same-origin authenticated backend and returns `{ bootstrapToken, expiresAt }`. |
| `host` | No | Exact widget-host origin; defaults to `https://widget.dokosoko.com`. HTTPS is required outside localhost. |
| `label` | No | Launcher and iframe accessibility label. |
| `position` | No | `left` or `right`; otherwise the saved widget appearance is used. |
| `initiallyOpen` | No | Opens after mounting. Defaults to `false`. |

## Lifecycle

```ts
const widget = mountWidget({ widgetId, getToken });

const unsubscribe = widget.on("sessionExpired", () => {
  // The loader automatically asks getToken for a new bootstrap.
});

widget.open();
widget.close();
unsubscribe();
widget.destroy();
```

Events are `ready`, `open`, `close`, `error`, and `sessionExpired`. Call `destroy()` when a single-page application permanently removes the integration.

The loader validates the widget UUID and host before creating the iframe. It accepts only an exact credential-free HTTPS origin, with localhost HTTP allowed for development. Tokens are sent through exact-origin `postMessage`, never through iframe query parameters.
