# DokoSoko widget backend SDK

Server-only TypeScript client for creating authenticated DokoSoko widget sessions. Never import this package into a client component or expose a widget secret to the browser.

```ts
import DokoSokoWidgetBackend from "@dokosoko/widget-backend";

const dokosoko = new DokoSokoWidgetBackend({
  widgetSecret: process.env.DOKOSOKO_WIDGET_SECRET!,
  baseURL: process.env.DOKOSOKO_API_URL!,
});

export async function POST(request: Request) {
  const user = await requireAuthenticatedUser(request);
  const session = await dokosoko.widgetSessions.create({
    widgetId: process.env.DOKOSOKO_WIDGET_ID!,
    userId: user.id,
    organizationId: user.organizationId,
    origin: new URL(request.url).origin,
  }, { idempotencyKey: crypto.randomUUID() });

  return Response.json(session, { headers: { "cache-control": "no-store" } });
}
```

The canonical API contract and Stainless configuration live in `dokosoko-service/api/widget-runtime.openapi.yaml` and `dokosoko-service/stainless.yml`. This beta repository is intentionally shaped like the generated API; Stainless becomes the release authority after the contract preview is approved. Browser runtimes are explicitly unsupported.

`npm run generate` regenerates the checked-in request and response types directly from that contract. The small transport wrapper adds the server-runtime guard, timeouts, retries, and typed DokoSoko errors; it does not redefine the wire schema.

## Client options

| Option | Default | Description |
| --- | --- | --- |
| `widgetSecret` | Required | Server-only `doko_wsk_...` credential scoped to one widget. |
| `baseURL` | `https://api.dokosoko.com` | Exact credential-free API origin. HTTPS is required outside localhost. |
| `timeoutMs` | `10000` | Timeout for each attempt. |
| `maxRetries` | `2` | Retries for network failures, `408`, `429`, and `5xx` responses. |
| `fetch` | `globalThis.fetch` | Optional server-side fetch implementation. |

Pass a stable `idempotencyKey` when the same logical bootstrap request might be retried. Never reuse the key for a different widget, user, organisation, or origin.

## Errors

Non-retryable API responses throw `DokoSokoWidgetError` with:

- `status` — HTTP status;
- `code` — stable DokoSoko error code;
- `requestId` — correlation ID when supplied by the runtime;
- `details` — bounded structured details when present.

Do not log the widget secret or returned bootstrap. Log the request ID and bounded error code, then return a generic sign-in or retry message to the browser.

## Verification and generation

```bash
npm run generate
npm run typecheck
npm test
```
